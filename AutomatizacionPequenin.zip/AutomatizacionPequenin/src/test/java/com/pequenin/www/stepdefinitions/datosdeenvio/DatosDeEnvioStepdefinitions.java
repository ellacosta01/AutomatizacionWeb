package com.pequenin.www.stepdefinitions.datosdeenvio;

import com.pequenin.www.questions.datosdeenvio.Validar;
import com.pequenin.www.questions.datosdeenvio.Verificar;
import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.datosdeenvio.IngresarLosDatos;
import com.pequenin.www.tasks.datosdeenvio.SeleccionaElBoton;
import com.pequenin.www.tasks.datosdeenvio.SelecionarLaOpcion;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.GivenWhenThen;
import org.hamcrest.Matchers;

import java.util.List;

public class DatosDeEnvioStepdefinitions {

    @Cuando("^el usuario selecciona continuar en el carro$")
    public void elUsuarioSeleccionaContinuarEnElCarro() {

        Hook.getUser().attemptsTo(SelecionarLaOpcion.continuarEnElcarro());
    }

    @Cuando("^selecciona finalizar compra$")
    public void seleccionaFinalizarCompra() {
        Hook.getUser().attemptsTo(SeleccionaElBoton.finalizarCompra());
    }

    @Cuando("^diligencia sus datos de envio$")
    public void elUsuarioDiligenciaSusDatos(List<String> listaRellenar) {
        Hook.getUser().attemptsTo(IngresarLosDatos.enElFormulario
                (listaRellenar.get(0),listaRellenar.get(1),listaRellenar.get(2),listaRellenar.get(3),listaRellenar.get(4),listaRellenar.get(5),
                        listaRellenar.get(6),listaRellenar.get(7),listaRellenar.get(8),listaRellenar.get(9)));
    }


    @Entonces("^deberia visualizar los datos de envio$")
    public void deberiaVisualizarLosDatosDeEnvio(List<String>listaValidar) {
        Hook.getUser().should(GivenWhenThen.seeThat(Validar.queSeaLaDireccionCorrecta(), Matchers.equalTo(listaValidar.get(0))));
        Hook.getUser().should(GivenWhenThen.seeThat(Verificar.elBarrioOApato(), Matchers.equalTo(listaValidar.get(1))));
        Hook.getUser().should(GivenWhenThen.seeThat(Verificar.elBarrioOApato(), Matchers.equalTo(listaValidar.get(1))));

    }


}

package com.pequenin.www.stepdefinitions.pagoscontraentrega;

import com.pequenin.www.interactions.Esperar;
import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.pagoscontraentrega.Selecciona;
import cucumber.api.java.ast.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage.*;

public class PagoContraEntregaStepDefinitions {

    @Cuando("^el usuario elige la opcion de pago contra entrega$")
    public void elUsuarioEligeLaOpcionDePagoContraEntrega() {

        Hook.getUser().attemptsTo(Selecciona.elMetodoDePago());
    }

    @Cuando("^el usuario selecciona continuar$")
    public void elUsuarioSeleccionaContinuar() {
        Hook.getUser().attemptsTo(Scroll.to(BTN_CONTINUAR).andAlignToBottom(),
                Esperar.unTiempo(3000),
                MoveMouse.to(BTN_CONTINUAR).andThen(actions -> actions.click()));
    }

    @Cuando("^acepta que se redimio correctamente$")
    public void aceptaQueSeRedimioCorrectamente() {
        Hook.getUser().attemptsTo(Click.on(BTN_ACEPTAR_REDENCION),
                Esperar.unTiempo(3000));

    }

    @Entonces("^el usuario vera que se realizo el descuento de los puntos$")
    public void elUsuarioVeraQueSeRealizoElDescuentoDeLosPuntos() {

    }

}

package com.pequenin.www.stepdefinitions.hook;

import cucumber.api.java.Before;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

public class Hook {

    @Managed(driver = "chrome")
    WebDriver suNavegador;
    private static Actor User = Actor.named("User");


    @Before
    public void setUp() {
        User.can(BrowseTheWeb.with(suNavegador));
    }

    public static Actor getUser() {
        return User;
    }
}

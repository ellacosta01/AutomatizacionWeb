package com.pequenin.www.stepdefinitions.datosenpayu;

import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.datosenpayu.Confirmar;
import com.pequenin.www.tasks.datosenpayu.EnviarLosDatos;
import cucumber.api.java.ast.Cuando;
import cucumber.api.java.es.Dado;

import java.util.List;

public class DatosEnPayuStepdefinitions {

    @Dado("^que el usuario se encuentra por confirmar el paso a la pasarela de pago$")
    public void queElUsuarioSeEncuentraPorConfirmarElPasoALaPasarelaDePago() {
        Hook.getUser().attemptsTo(Confirmar.elpago());

    }

    @Cuando("^diligencias los datos para el pago$")
    public void diligenciasLosDatosParaElPago(List<String> listaDatos) {
        Hook.getUser().attemptsTo(EnviarLosDatos.paraElPago(listaDatos.get(0), listaDatos.get(1),
                listaDatos.get(2), listaDatos.get(3), listaDatos.get(4), listaDatos.get(5), listaDatos.get(6), listaDatos.get(7)));
    }
}

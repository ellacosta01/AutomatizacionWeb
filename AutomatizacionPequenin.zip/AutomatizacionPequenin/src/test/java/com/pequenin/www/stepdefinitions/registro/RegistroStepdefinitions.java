package com.pequenin.www.stepdefinitions.registro;

import com.pequenin.www.questions.registro.ValidarMensaje;
import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.abrirnavegador.AbrirElNavegador;
import com.pequenin.www.tasks.registro.*;
import com.pequenin.www.userinterfaces.registro.PequeninRegistoPage;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.GivenWhenThen;
import org.hamcrest.Matchers;

import java.util.List;

public class RegistroStepdefinitions {
    PequeninRegistoPage pequeninRegistoPage;

    @Dado("^que estoy en la pagina del club pequenin$")
    public void queEstoyEnLaPaginaDelClubPequenin() {
        Hook.getUser().wasAbleTo(AbrirElNavegador.en(pequeninRegistoPage));
    }

    @Cuando("^diligencio el formato de informacion personal$")
    public void diligencioElFormatoDeRegistro(List<String> lista) {
        Hook.getUser().attemptsTo(Rellenar.elformularioDeRegistro(lista.get(0), lista.get(1), lista.get(2), lista.get(3), lista.get(4), lista.get(5)));
    }

    @Cuando("^selecciono el rol$")
    public void seleccionoElRol(List<String> listaRol) {
        Hook.getUser().attemptsTo(Seleccionar.elRol(listaRol));
    }

    @Cuando("^diligencio los datos de contacto$")
    public void diligencioLosDatosDeContacto(List<String> listaDatosContacto) {
        Hook.getUser().attemptsTo(Escribir.losDatosDeContacto(listaDatosContacto.get(0), listaDatosContacto.get(1)));
    }

    @Cuando("^diligencio los datos de residencia$")
    public void diligencioLosDatosDeResidencia(List<String> listaDatosDeResidencia) {
        Hook.getUser().attemptsTo(Diligenciar.losDatosDeResidencia(listaDatosDeResidencia.get(0), listaDatosDeResidencia.get(1),
                listaDatosDeResidencia.get(2), listaDatosDeResidencia.get(3)));

    }

    @Cuando("^selecciono la etapa quedar en embarazo$")
    public void seleccionoLaEtapa() {
        Hook.getUser().attemptsTo(Escoger.laEtapa());
    }

    @Cuando("^creo una clave para el registro$")
    public void creoUnaClaveParaElRegistro(List<String> listaClave) {
        Hook.getUser().attemptsTo(Crear.laClave(listaClave.get(0)));

    }

    @Entonces("^deberia ver un mensaje que indique que debe activar la cuenta$")
    public void deberiaVerUnMensajeQueIndiqueQueDebeActivarLaCuenta(List<String> listaMensaje) {
        Hook.getUser().should(GivenWhenThen.seeThat(ValidarMensaje.enElUltimoPaso(), Matchers.equalTo(listaMensaje.get(0))));
    }
}

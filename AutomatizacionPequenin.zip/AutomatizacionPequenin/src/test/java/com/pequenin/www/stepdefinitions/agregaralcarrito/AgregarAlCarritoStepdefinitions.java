package com.pequenin.www.stepdefinitions.agregaralcarrito;

import com.pequenin.www.questions.agregaralcarrito.Validar;
import com.pequenin.www.questions.iniciarsesion.ValidarRespuesta;
import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.agregaralcarrito.AgregarAlCarrito;
import com.pequenin.www.tasks.agregaralcarrito.IrAlCatalogo;
import com.pequenin.www.tasks.agregaralcarrito.Seleccionar;
import com.pequenin.www.tasks.agregaralcarrito.VerElDetalle;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.GivenWhenThen;
import org.hamcrest.Matchers;

import java.util.List;

public class AgregarAlCarritoStepdefinitions {
    @Cuando("^voy al catalogo de premios$")
    public void voyAlCatalogoDePremios() {
        Hook.getUser().attemptsTo(IrAlCatalogo.dePremios());
    }

    @Cuando("^selecciono ver premio$")
    public void seleccionoVerPremio(List<String> listaDatosPremio) {
        Hook.getUser().attemptsTo(Seleccionar.elPremio(listaDatosPremio.get(0)));
    }

    @Cuando("^lo agrego al carrito$")
    public void loAgregoAlCarrito() {
        Hook.getUser().attemptsTo(AgregarAlCarrito.elPremio());

    }

    @Cuando("^veo el detalle del carrito$")
    public void veoElDetalleDelCarrito() {
        Hook.getUser().attemptsTo(VerElDetalle.delcarrito());

    }
    @Entonces("^debería ver que el producto se agregó correctamente$")
    public void deberíaVerQueElProductoSeAgregóCorrectamente(List<String> listaDatosPremio) {
        Hook.getUser().should(GivenWhenThen.seeThat(Validar.queElProductoSeAgregoCorrectamente(), Matchers.equalTo(listaDatosPremio.get(0))));
    }

}

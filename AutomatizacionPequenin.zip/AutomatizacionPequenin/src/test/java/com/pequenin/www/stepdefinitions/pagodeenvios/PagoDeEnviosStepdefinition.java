package com.pequenin.www.stepdefinitions.pagodeenvios;

import com.pequenin.www.questions.iniciarsesion.ValidarRespuesta;
import com.pequenin.www.questions.pagosdeenvio.Validar;
import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.pagodeenvios.ConfirmarlaDirreccion;
import com.pequenin.www.tasks.pagodeenvios.Seleccionar;
import cucumber.api.java.ast.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.GivenWhenThen;
import org.hamcrest.Matchers;

import java.util.List;

public class PagoDeEnviosStepdefinition {
    @Cuando("^el usuario esta en la confirmacion de la direccion$")
    public void elUsuarioEstaEnLaConfirmacionDeLaDireccion() {
        Hook.getUser().attemptsTo(ConfirmarlaDirreccion.deEnvio());
    }

    @Cuando("^elige la opcion con que desea pagar$")
    public void eligeLaOpcionConQueDeseaPagar() {
        Hook.getUser().attemptsTo(Seleccionar.enMetodoDePago());
    }

    @Entonces("^deberia ver que finalizó el proceso$")
    public void deberiaVerQueFinalizóElProceso(List<String> listaMensaje) {
        Hook.getUser().should(GivenWhenThen.seeThat(Validar.elMensaje(),Matchers.equalTo(listaMensaje.get(0))));
    }


}

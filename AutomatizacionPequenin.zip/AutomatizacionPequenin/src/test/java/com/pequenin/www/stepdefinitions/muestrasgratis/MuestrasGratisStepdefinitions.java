package com.pequenin.www.stepdefinitions.muestrasgratis;

import com.pequenin.www.questions.muestragratis.ValidarElMensaje;
import com.pequenin.www.questions.muestragratis.ValidarMensaje;
import com.pequenin.www.questions.muestragratis.ValidarMensajeError;
import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.muestrasgratis.*;
import com.pequenin.www.tasks.muestrasgratis.DiligenciarLosDatos;
import com.pequenin.www.tasks.muestrasgratis.EscogerMuestra;
import com.pequenin.www.tasks.muestrasgratis.RedimirMasMuestrasGratis;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.GivenWhenThen;
import org.hamcrest.Matchers;

import java.util.List;

public class MuestrasGratisStepdefinitions {
    @Cuando("^el usuario esta en la seccion de productos$")
    public void elUsuarioEstaEnLaSeccionDeProductos() {
        Hook.getUser().attemptsTo(SeleccionarProductos.enElHome());
    }

    @Cuando("^selecciona panales  premiun touch del cual desea la muestra$")
    public void seleccionaPanalesPremiunTouchDelCualDeseaLaMuestra() {
        Hook.getUser().attemptsTo(SeleccionarPremiunTouch.dePanalesPequenin());
    }

    @Cuando("^realiza el proceso para solicitar una muestra$")
    public void realizaElProcesoParaSolicitarUnaMuestra() {
        Hook.getUser().attemptsTo(RealizarElProceso.deSolicitarUnaMuestra());
    }

    @Cuando("^escoge de las muestras dispoble la que va a redimir$")
    public void escogeDeLasMuestrasDispobleLaQueVaARedimir() {
        Hook.getUser().attemptsTo(EscogerMuestra.disponible());
    }

    @Cuando("^diligencia sus datos de envio de la muestra$")
    public void diligenciaSusDatosDeEnvioDeLaMuestra(List<String> listaDatosDeEnvio) {
        Hook.getUser().attemptsTo(DiligenciarLosDatos.deEnvio(listaDatosDeEnvio.get(0), listaDatosDeEnvio.get(1),
                listaDatosDeEnvio.get(2), listaDatosDeEnvio.get(3), listaDatosDeEnvio.get(4), listaDatosDeEnvio.get(5),
                listaDatosDeEnvio.get(6)));
    }

    @Entonces("^deberia ve el mensaje de muestra exitosa$")
    public void deberiaVeElMensajeDeMuestraExitosa(List<String> listaMensaje) {
        Hook.getUser().should(GivenWhenThen.seeThat(ValidarElMensaje.deMuestraExitosa(), Matchers.equalTo(listaMensaje.get(0))));
    }

    @Cuando("^elige mas muestras de las permitidas por mes$")
    public void eligeMasMuestrasDeLasPermitidasPorMes() {
        Hook.getUser().attemptsTo(RedimirMasMuestrasGratis.deLasPermitidas());
    }


    @Entonces("^deberia ve el mensaje un mensaje de error$")
    public void deberiaVeElMensajeUnMensajeDeError(List<String> listaMensajeError) {
        Hook.getUser().should(GivenWhenThen.seeThat(ValidarMensaje.deMuestraCompleta(), Matchers.equalTo(listaMensajeError.get(0))));
    }

    @Cuando("^elige dos muestras del mismo producto$")
    public void eligeDosMuestrasDelMismoProducto() {
        Hook.getUser().attemptsTo(RedimirDosMuestras.iguales());
    }

    @Entonces("^deberia ver el mensaje un mensaje de error sobre la redencion doble$")
    public void deberiaVerElMensajeUnMensajeDeErrorSobreLaRedencionDoble(List<String> listaMensajeDeError) {
        Hook.getUser().should(GivenWhenThen.seeThat(ValidarMensajeError.deMuestraDoble(), Matchers.equalTo(listaMensajeDeError.get(0))));
    }
}
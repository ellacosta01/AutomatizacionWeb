package com.pequenin.www.stepdefinitions.iniciosesion;

import com.pequenin.www.questions.iniciarsesion.ValidarMensaje;
import com.pequenin.www.questions.iniciarsesion.ValidarNombre;
import com.pequenin.www.questions.iniciarsesion.ValidarRespuesta;
import com.pequenin.www.stepdefinitions.hook.Hook;
import com.pequenin.www.tasks.iniciosesion.IngresarLosDatos;
import com.pequenin.www.tasks.iniciosesion.SeleccionarBoton;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.GivenWhenThen;
import org.hamcrest.Matchers;

import java.util.List;

public class InicioSesionStepdefinitions {

    @Cuando("^ingreso mis credenciales$")
    public void ingresoMisCredenciales(List<String> listaInicioSesion) {
        Hook.getUser().attemptsTo(IngresarLosDatos.paraIniciarSesion(listaInicioSesion.get(0), listaInicioSesion.get(1)));
    }

    @Cuando("^Selecciono Iniciar Sesion$")
    public void seleccionoIniciarSesion() {
        Hook.getUser().attemptsTo(SeleccionarBoton.IniciarSesion());
    }

    @Entonces("^deberia ver el nombre del usuario$")
    public void deberiaVerElNombreDelUsuario(List<String> listaValidacion) {

        Hook.getUser().should(GivenWhenThen.seeThat(ValidarNombre.delUsuario(), Matchers.equalTo(listaValidacion.get(0))));

    }
    @Entonces("^deberia ver un mensaje en el campo de clave que indique que los datos son incorrectos$")
    public void deberiaVerUnMensajeEnElCampoDeClaveQueIndiqueQueLosDatosSonIncorrectos(List<String> listaValidacionRespuesta) {
        Hook.getUser().should(GivenWhenThen.seeThat(ValidarMensaje.enElCampoClave(),Matchers.equalTo(listaValidacionRespuesta.get(0))));
    }

    @Entonces("^deberia ver un mensaje en el campo de correo que indique que los datos son incorrectos$")
    public void deberiaVerUnMensajeEnElCampoDeCorreoQueIndiqueQueLosDatosSonIncorrectos(List<String> listaValidacionMensaje) {
        Hook.getUser().should(GivenWhenThen.seeThat(ValidarRespuesta.enElCampoCorreo(), Matchers.equalTo(listaValidacionMensaje.get(0))));
    }


    @Entonces("^deberia ver un mensaje en el campo de correo electronico que indique que los datos son incorrectos$")
    public void deberiaVerUnMensajeEnElCampoDeCorreoElectronicoQueIndiqueQueLosDatosSonIncorrectos(List<String> listaValidacionMensaje) {


    }


}

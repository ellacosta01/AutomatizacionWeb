package com.pequenin.www.runners.muestragratis;


import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src\\test\\resources\\muestras_gratis.feature",
        glue = "com.pequenin.www.stepdefinitions",
        snippets = SnippetType.CAMELCASE)

public class MuestrasGratisRunner {
}

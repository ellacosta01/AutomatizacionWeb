package com.pequenin.www.questions.agregaralcarrito;

import com.pequenin.www.userinterfaces.agregaralcarrito.CatalogoPremiosPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class Validar implements Question<String> {
    public static Validar queElProductoSeAgregoCorrectamente(){
        return new Validar();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(CatalogoPremiosPage.BTN_PRODUCTO_AGREGADO).viewedBy(actor).asString();
    }
}

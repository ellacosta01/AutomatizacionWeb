package com.pequenin.www.userinterfaces.iniciosesion;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

public class InicioSesionPage extends PageObject


{
    public static final Target TXT_CORREO = Target.the("Escribir correo").located(By.xpath("//input[@name='email']"));
    public static final Target TXT_CLAVE = Target.the("Escribir clave").located(By.xpath("//input[@name='password']"));
    public static final Target BTN_INICIAR_SESION = Target.the("Boton Iniciar sesion").located(By.xpath("//button[@id='f-a-button__login']"));
    public static final Target TXT_MSJ_ERROR_CLAVE = Target.the("Mensaje error clave incorrecta").located(By.xpath("//span[@class='f-m-login__error']"));
    public static final Target TXT_MSJ_ERROR_CORREO = Target.the("Mensaje error correo incorrecta").located(By.xpath("//span[@class='f-a-input__error']"));
    public static final Target TXT_VENTANA_EMERGENTE = Target.the("Mensaje Ventana Emergente").located(By.xpath("//div[@class='f-a-toast undefined']/span"));

}

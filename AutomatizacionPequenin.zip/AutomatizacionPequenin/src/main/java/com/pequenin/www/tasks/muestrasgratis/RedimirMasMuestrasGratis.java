package com.pequenin.www.tasks.muestrasgratis;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.muestrasgratis.MuestrasGratisPage.*;

public class RedimirMasMuestrasGratis implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {


        actor.attemptsTo(
                Esperar.unTiempo(3000),
                Scroll.to(BTN_PREMIUM_TOUCH5).andAlignToBottom(),
                Click.on(BTN_PURE_SKIN),
                Esperar.unTiempo(3000),
                Click.on(BTN_PREMIUM_TOUCH3),
                Esperar.unTiempo(3000),
                Click.on(BTN_NEW_BABY)

        );

    }
    public static RedimirMasMuestrasGratis deLasPermitidas(){
        return Tasks.instrumented(RedimirMasMuestrasGratis.class);
    }
}

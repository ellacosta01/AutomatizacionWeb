package com.pequenin.www.tasks.datosdeenvio;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.agregaralcarrito.CatalogoPremiosPage.BTN_CONTINUAR_CARRITO;

public class SelecionarLaOpcion implements Task {


    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_CONTINUAR_CARRITO));

    }

    public static SelecionarLaOpcion continuarEnElcarro() {
        return Tasks.instrumented(SelecionarLaOpcion.class);
    }
}

package com.pequenin.www.userinterfaces.pagosdeenvio;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class PagosDeEnvioPage {
    public static final Target BTN_CONFIRMAR = Target.the("Boton confirmar direccion").located(By.xpath("//button[@id='f-a-button__adress-confirmation']"));

    public static final Target BTN_PAGO_EN_LINEA = Target.the("Boton pago en linea").located(By.xpath("//input[@id='radioOnline']"));

    public static final Target SELECT_TIPO_DIRECCION = Target.the("Lista tipo de direccion").located(By.xpath("//div[@id='f-a-addressPart1select']"));

    public static Target OPT_TIPO_DIRECCION_ESPECIFICA(String tipoDeDireccion) {
        return Target.the("Tipo de Direccion").located(By.xpath("//li[@class='f-a-selectBox__option']/p[text()='" + tipoDeDireccion + "']"));
    }

    public static final Target BTN_CONTINUAR = Target.the("Boton continuar").located(By.xpath("//button[@id='f-a-button__shipping-payment']/p[text()='Continuar']"));

    public static final Target  TXT_MENSAJE =Target.the("Mensaje de coordinacion").located(By.xpath("//h2[@class='f-m-redirection-notification__title']"));

    public static final Target  BTN_CONFIRMAR_PAGO =Target.the("Boton confirmar pago").located(By.xpath("//input[@name='Submit']"));

    public static final Target  BTN_PAGO_CONTRA_ENTREGA =Target.the("Boton pago contra entrega").located(By.xpath("//input[@id='radioUpon']"));

    public static final Target  BTN_ACEPTAR_REDENCION =Target.the("Aceptar redencion").located(By.xpath("//button[@id='f-a-button__shipping-payment']/p[text()='Continuar']"));

}

package com.pequenin.www.interactions;

import com.pequenin.www.userinterfaces.registro.PequeninRegistoPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.questions.Text;

public class SeleccionarFecha implements Interaction {

    String dia;
    String mes;
    String year;

    public SeleccionarFecha(String dia, String mes, String year) {
        this.dia = dia;
        this.mes = mes;
        this.year = year;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(PequeninRegistoPage.TXT_FECHA));
        if (!Text.of(PequeninRegistoPage.BTN_YEAR).viewedBy(actor).asString().equals(year)) {
            actor.attemptsTo(Click.on(PequeninRegistoPage.BTN_YEAR));
            actor.attemptsTo(Scroll.to(PequeninRegistoPage.BTN_YEAR_ESPECIFICO(String.valueOf(Integer.parseInt(year) + 8))).andAlignToBottom());
            actor.attemptsTo(Click.on(PequeninRegistoPage.BTN_YEAR_ESPECIFICO(year)));
        }
        if (!Text.of(PequeninRegistoPage.BTN_MES).viewedBy(actor).asString().equals(mes)) {
            actor.attemptsTo(Click.on(PequeninRegistoPage.BTN_MES));
            actor.attemptsTo(Click.on(PequeninRegistoPage.BTN_MES_ESPECIFICO(mes)));
        }
        actor.attemptsTo(Click.on(PequeninRegistoPage.BTN_DIA_ESPECIFICO(dia)));
    }

    public static SeleccionarFecha deNacimiento(String dia, String mes, String year){
        return Tasks.instrumented(SeleccionarFecha.class, dia, mes, year);
    }
}

package com.pequenin.www.interactions;

import com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Scroll;

public class SeleccionarTipoDeDireccion implements Interaction {
    String direccion;

    public SeleccionarTipoDeDireccion(String direccion) {
        this.direccion = direccion;
    }


    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(PagosDeEnvioPage.SELECT_TIPO_DIRECCION));
        actor.attemptsTo(Scroll.to(PagosDeEnvioPage.OPT_TIPO_DIRECCION_ESPECIFICA(direccion)).andAlignToBottom());
        actor.attemptsTo(Click.on(PagosDeEnvioPage.OPT_TIPO_DIRECCION_ESPECIFICA(direccion)));
    }

    public static SeleccionarTipoDeDireccion deEnvio(String direccion) {
        return Tasks.instrumented(SeleccionarTipoDeDireccion.class, direccion);
    }

}

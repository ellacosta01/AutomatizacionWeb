package com.pequenin.www.tasks.muestrasgratis;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.home.HomePage.BTN_PREMIUN_TOUCH;

public class SeleccionarPremiunTouch implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_PREMIUN_TOUCH)
        );
    }

    public static SeleccionarPremiunTouch dePanalesPequenin() {
        return Tasks.instrumented(SeleccionarPremiunTouch.class);
    }
}

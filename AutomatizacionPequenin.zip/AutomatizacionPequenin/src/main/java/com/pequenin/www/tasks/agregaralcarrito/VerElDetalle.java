package com.pequenin.www.tasks.agregaralcarrito;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.agregaralcarrito.CatalogoPremiosPage.BTN_VER_AL_CARRITO;

public class VerElDetalle implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_VER_AL_CARRITO)
        );

    }
    public static VerElDetalle delcarrito(){
        return Tasks.instrumented(VerElDetalle.class);
    }
}

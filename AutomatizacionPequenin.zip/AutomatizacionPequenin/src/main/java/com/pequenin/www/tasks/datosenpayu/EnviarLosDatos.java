package com.pequenin.www.tasks.datosenpayu;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.actions.SelectFromOptions;
import net.serenitybdd.screenplay.actions.selectactions.SelectByIndexFromTarget;

import static com.pequenin.www.userinterfaces.datosenpayu.DatosPayuPage.*;
import static com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage.BTN_CONFIRMAR_PAGO;

public class EnviarLosDatos implements Task {
    String nombreTarjeta;
    String docIdentidad;
    String numTarjerta;
    String codSeguridad;
    String mesVencimiento;
    String yearVencimiento;
    String cuotas;
    String telefonoCelular;

    public EnviarLosDatos(String nombreTarjeta, String docIdentidad, String numTarjerta,
                          String codSeguridad, String mesVencimiento, String yearVencimiento,
                          String cuotas, String telefonoCelular) {
        this.nombreTarjeta = nombreTarjeta;
        this.docIdentidad = docIdentidad;
        this.numTarjerta = numTarjerta;
        this.codSeguridad = codSeguridad;
        this.mesVencimiento = mesVencimiento;
        this.yearVencimiento = yearVencimiento;
        this.cuotas = cuotas;
        this.telefonoCelular = telefonoCelular;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Esperar.unTiempo(3000),
                Click.on(BTN_CONFIRMAR_PAGO),
                Esperar.unTiempo(20000),
                Click.on(BTN_FRANQUICIA),
                Esperar.unTiempo(3000),
                Enter.theValue(nombreTarjeta).into(TXT_NOMBRE_USUARIO),
                Enter.theValue(docIdentidad).into(TXT_DOCUMENTO),
                Enter.theValue(numTarjerta).into(TXT_NUM_TARJETA),
                Enter.theValue(codSeguridad).into(TXT_CODIGO_SEGURIDAD),
                Scroll.to(TXT_CODIGO_SEGURIDAD),
                SelectFromOptions.byIndex(10).from(SELECT_DIA_VENCIMIENTO),
                SelectFromOptions.byIndex(1).from(SELECT_YEAR_VENCIMIENTO),
                SelectFromOptions.byIndex(1).from(SELECT_CUOTAS),
                Enter.theValue(telefonoCelular).into(TXT_CELULAR),
                Esperar.unTiempo(2000),
                Click.on(CHECK_TERMINOS_CONDICIONES),
                Click.on(BTN_PAGAR),
                Esperar.unTiempo(5000));

    }

    public static EnviarLosDatos paraElPago(String nombreTarjeta, String docIdentidad, String numTarjerta,
                                            String codSeguridad, String mesVencimiento, String yearVencimiento,
                                            String cuotas, String telefonoCelular) {
        return Tasks.instrumented(EnviarLosDatos.class, nombreTarjeta,docIdentidad,numTarjerta,
                codSeguridad,mesVencimiento,yearVencimiento,cuotas,telefonoCelular);
    }
}

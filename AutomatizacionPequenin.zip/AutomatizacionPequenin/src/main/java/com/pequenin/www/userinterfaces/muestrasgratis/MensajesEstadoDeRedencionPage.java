package com.pequenin.www.userinterfaces.muestrasgratis;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class MensajesEstadoDeRedencionPage {
    public static final Target TXT_SOLICITA_MUESTRA = Target.the("Texto Solicitar Muestra").located(By.xpath("//p[@class='f-m-modals-samples__title' and text()='¡Solicitud de muestra exitosa!']"));
    public static final Target TXT_MUESTRA_COMPLETA = Target.the("Texto de Solicitar Muestra Completo").located(By.xpath("//p[@class='f-m-modals-samples__title' and text()='Tu muestra está completa']"));
    public static final Target TXT_MUESTRA_DOBLE = Target.the("Texto de Solicitar Muestra Doble").located(By.xpath("//div[@class='f-a-toast undefined']/span"));

}

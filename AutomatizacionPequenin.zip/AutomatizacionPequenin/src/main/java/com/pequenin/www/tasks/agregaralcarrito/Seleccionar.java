package com.pequenin.www.tasks.agregaralcarrito;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Scroll;
import static com.pequenin.www.userinterfaces.agregaralcarrito.CatalogoPremiosPage.BTN_KIT_DE_HERRAMIENTAS;

public class Seleccionar implements Task {

    String premio;

    public Seleccionar(String premio) {
        this.premio = premio;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Scroll.to(BTN_KIT_DE_HERRAMIENTAS).andAlignToBottom(),
                Esperar.unTiempo(3000),
                Click.on(BTN_KIT_DE_HERRAMIENTAS));
    }

    public static Seleccionar elPremio(String premio) {
        return Tasks.instrumented(Seleccionar.class, premio);
    }
}

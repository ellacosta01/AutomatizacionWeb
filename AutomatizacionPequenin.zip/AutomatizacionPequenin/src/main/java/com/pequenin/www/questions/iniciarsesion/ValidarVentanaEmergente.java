package com.pequenin.www.questions.iniciarsesion;

import com.pequenin.www.userinterfaces.iniciosesion.InicioSesionPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ValidarVentanaEmergente implements Question<String> {
    public static ValidarVentanaEmergente deError(){
        return new ValidarVentanaEmergente();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(InicioSesionPage.TXT_VENTANA_EMERGENTE).viewedBy(actor).asString();
    }
}

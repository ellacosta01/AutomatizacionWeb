package com.pequenin.www.questions.muestragratis;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static com.pequenin.www.userinterfaces.muestrasgratis.MensajesEstadoDeRedencionPage.TXT_MUESTRA_COMPLETA;

public class ValidarMensaje  implements Question<String> {

public static ValidarMensaje deMuestraCompleta(){
        return new ValidarMensaje();
        }


@Override
public String answeredBy(Actor actor) {
        return Text.of(TXT_MUESTRA_COMPLETA).viewedBy(actor).asString();
        }
        }

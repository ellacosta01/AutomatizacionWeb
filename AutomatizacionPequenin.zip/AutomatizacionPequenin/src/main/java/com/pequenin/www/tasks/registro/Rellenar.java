package com.pequenin.www.tasks.registro;

import com.pequenin.www.interactions.SeleccionarFecha;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.pequenin.www.userinterfaces.home.HomePage.BTN_REGISTRO;
import static com.pequenin.www.userinterfaces.registro.PequeninRegistoPage.*;

public class Rellenar implements Task {

    String nombre;
    String apellido;
    String numDocumento;
    String dia;
    String mes;
    String year;

    public Rellenar(String nombre, String apellido, String numDocumento, String dia, String mes, String year) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.numDocumento = numDocumento;
        this.dia = dia;
        this.mes = mes;
        this.year = year;
    }


    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_REGISTRO),
                Click.on(BTN_COMENZAR),
                Click.on(TXT_NOMBRE),
                Enter.theValue(nombre).into(TXT_NOMBRE),
                Click.on(TXT_APELLIDO),
                Enter.theValue(apellido).into(TXT_APELLIDO),
                Click.on(TXT_CEDULA),
                Enter.theValue(numDocumento).into(TXT_CEDULA),
                Click.on(BTN_TERMINOS_CONDICIONES));
        actor.attemptsTo(SeleccionarFecha.deNacimiento(dia, mes, year));
        actor.attemptsTo(Click.on(BTN_SIGUIENTE));

    }

    public static Rellenar elformularioDeRegistro(String nombre, String apellido, String numDocumento, String dia, String mes, String year) {
        return Tasks.instrumented(Rellenar.class, nombre, apellido, numDocumento, dia, mes, year);
    }
}

package com.pequenin.www.userinterfaces.muestrasgratis;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class MuestrasGratisPage {

    public static final Target BTN_CERRAR_VENTANA_MUESTRAS_GRATIS = Target.the("Boton cerrar ventana muestras gratis").located(By.xpath("//span[@class='icon-ico-x']"));
    public static final Target BTN_NEW_BABY = Target.the("Boton New Baby").located(By.xpath("//h3[@class='f-a-sample-card__name' and text()='New Baby (Etapa 0)']"));
    public static final Target BTN_SOLICITA_MUESTRA = Target.the("Boton Solicitar Muestra").located(By.xpath("//button[@id='f-a-button__f-m-selected-samples']"));
    public static final Target BTN_PURE_SKIN = Target.the("Tarjeta Pure Skin").located(By.xpath("//h3[@class='f-a-sample-card__name' and text()='Pure Skin']"));
    public static final Target BTN_PREMIUM_TOUCH3 = Target.the("Tarjeta Premium Touch 3").located(By.xpath("(//h3[@class='f-a-sample-card__name'])[3]"));
    public static final Target BTN_PREMIUM_TOUCH4 = Target.the("Tarjeta Premium Touch 4").located(By.xpath("(//h3[@class='f-a-sample-card__name'])[4]"));
    public static final Target BTN_PREMIUM_TOUCH5 = Target.the("Tarjeta Premium Touch 5").located(By.xpath("(//h3[@class='f-a-sample-card__name'])[5]"));



}

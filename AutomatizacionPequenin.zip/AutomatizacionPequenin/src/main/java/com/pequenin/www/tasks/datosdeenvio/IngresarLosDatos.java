package com.pequenin.www.tasks.datosdeenvio;

import com.pequenin.www.interactions.Esperar;
import com.pequenin.www.interactions.SeleccionarCiudad;
import com.pequenin.www.interactions.SeleccionarDepartamento;
import com.pequenin.www.interactions.SeleccionarTipoDeDireccion;
import net.serenitybdd.core.time.InternalSystemClock;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.datosdeenvio.DatosDeEnvioPage.*;

public class IngresarLosDatos implements Task {
    String nombre;
    String apellido;
    String tipoviaprincipal;
    String viaprincipal;
    String viasecundaria;
    String viacomplemento;
    String apto;
    String departamento;
    String ciudad;
    String numeroCelular;

    public IngresarLosDatos(
            String nombre, String apellido, String tipoviaprincipal,
            String viaprincipal, String viasecundaria, String viacomplemento,
            String apto, String departamento, String ciudad, String numeroCelular) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipoviaprincipal = tipoviaprincipal;
        this.viaprincipal = viaprincipal;
        this.viasecundaria = viasecundaria;
        this.viacomplemento = viacomplemento;
        this.apto = apto;
        this.departamento = departamento;
        this.ciudad = ciudad;
        this.numeroCelular = numeroCelular;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Enter.theValue(nombre).into(TXT_NOMBRE),
                Enter.theValue(apellido).into(TXT_APELLIDO),
                SeleccionarTipoDeDireccion.deEnvio(tipoviaprincipal),
                Enter.theValue(viaprincipal).into(TXT_VIA_PRINCIPAL),
                Enter.theValue(viasecundaria).into(TXT_VIA_SECUNDARIA),
                Enter.theValue(viacomplemento).into(TXT_VIA_COMPLEMENTO),
                Enter.theValue(apto).into(TXT_APTO),
                Esperar.unTiempo(3000),
                SeleccionarDepartamento.deEnvio(departamento),
                SeleccionarCiudad.deEnvio(ciudad),
                Click.on(BTN_NO_ACTALIZAR_DATOS),
                Enter.theValue(numeroCelular).into(TXT_NUMERO_CELULAR),
                Scroll.to(BTN_CONTINUAR).andAlignToBottom(),
                Esperar.unTiempo(3000),
                Click.on(BTN_CONTINUAR));
    }

    public static IngresarLosDatos enElFormulario(
            String nombre, String apellido, String tipoviaprincipal,
            String viaprincipal, String viasecundaria, String viacomplemento,
            String apto, String departamento, String ciudad, String numeroCelular) {
        return Tasks.instrumented(IngresarLosDatos.class, nombre, apellido, tipoviaprincipal, viaprincipal, viasecundaria, viacomplemento, apto, departamento, ciudad, numeroCelular);

    }
}

package com.pequenin.www.userinterfaces.home;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class HomePage {

    public static final Target BTN_INICIO_SESION = Target.the("Boton inicio sesion").located(By.xpath("//a[@class='f-m-header-start-session-item']"));
    public static final Target BTN_REGISTRO = Target.the("Boton comenzar").located(By.xpath("//button[@class='f-a-button f-a-button__primary-blue f-a-button__big f-m-header-start-session-item f-m-button']"));
    public static final Target BTN_CLUB_PEQUENIN = Target.the("Boton Club Pequenin").located(By.xpath("(//div[@class='f-m-nav-item__menu']/a)[2]"));
    public static final Target BTN_CATALOGO_DE_PREMIOS = Target.the("Catalogo de premios").located(By.xpath("(//a[@class='f-m-mega-menu__col-title'])[3]"));
    public static final Target TXT_NOMBRE_USUARIO = Target.the("Nombre del usuario").located(By.xpath("//p[@class='f-m-header-start-session__user-name']"));
        public static final Target BTN_PRODUCTOS = Target.the("Boton de productos").located(By.xpath("//div[@class='f-m-nav-item__menu']"));
    public static final Target BTN_PREMIUN_TOUCH = Target.the("Boton de premiun touch").located(By.xpath("(//div[@class='f-m-mega-menu__col ']//a)[3]"));





}

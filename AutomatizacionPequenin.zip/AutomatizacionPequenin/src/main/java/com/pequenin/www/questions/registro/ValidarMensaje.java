package com.pequenin.www.questions.registro;

import com.pequenin.www.userinterfaces.registro.UltimoPasoPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ValidarMensaje implements Question<String> {
    public static ValidarMensaje enElUltimoPaso() {
        return new ValidarMensaje();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(UltimoPasoPage.TXT_MENSAJE).viewedBy(actor).asString();
    }

    }

package com.pequenin.www.tasks.iniciosesion;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.iniciosesion.InicioSesionPage.BTN_INICIAR_SESION;

public class SeleccionarBoton implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_INICIAR_SESION));
    }

    public static SeleccionarBoton IniciarSesion() {
        return Tasks.instrumented(SeleccionarBoton.class);
    }
}

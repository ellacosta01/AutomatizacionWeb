package com.pequenin.www.userinterfaces.registro;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class SeleccionaEtapaPage {
    public static final Target BTN_QUEDAR_EN_EMBARAZO = Target.the("Boton Seleccionar quedar en embarazo")
            .located(By.xpath("(//div[@class='f-m-StepFiveRegister__stage '])[1]"));
    public static final Target BTN_SIGUIENTE = Target.the("Boton siguiente").located(By.xpath("//button[@id='f-a-button__next-step-five']"));

}

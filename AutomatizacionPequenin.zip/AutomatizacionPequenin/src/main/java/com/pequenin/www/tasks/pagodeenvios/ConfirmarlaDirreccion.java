package com.pequenin.www.tasks.pagodeenvios;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage.BTN_CONFIRMAR;

public class ConfirmarlaDirreccion implements Task {


    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Esperar.unTiempo(3000),
                Scroll.to(BTN_CONFIRMAR).andAlignToBottom(),
                Esperar.unTiempo(2000),
                MoveMouse.to(BTN_CONFIRMAR).andThen(actions -> actions.click()));
    }

    public static ConfirmarlaDirreccion deEnvio() {
        return Tasks.instrumented(ConfirmarlaDirreccion.class);

    }
}

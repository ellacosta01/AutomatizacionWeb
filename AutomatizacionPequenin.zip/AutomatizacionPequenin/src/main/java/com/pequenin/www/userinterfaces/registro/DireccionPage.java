package com.pequenin.www.userinterfaces.registro;


import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class DireccionPage {

    public static final Target SELECT_DEPARTAMENTO = Target.the("Departamento").located(By.xpath("//div[@id='f-a-department-select']"));
    public static final Target SELECT_CIUDAD = Target.the("Ciudad").located(By.xpath("//div[@id='f-a-city-select']"));
    public static Target OPT_DEPARTAMENTO_ESPECIFICO(String departamento) {
        return Target.the("Departamento especifico").located(By.xpath("//li[@class='f-a-selectBox__option']/p[text()='" + departamento + "']"));
    }

    public static Target OPT_CIUDAD_ESPECIFICA(String ciudad) {
        return Target.the("Ciudad especifica").located(By.xpath("//li[@class='f-a-selectBox__option']/p[text()='" + ciudad + "']"));
    }

    public static final Target TXT_DIRECCION = Target.the("Escribir direccion").located(By.xpath("//input[@name='address']"));
    public static final Target TXT_BARRIO = Target.the("Escribir barrio, unidad, apto").located(By.xpath("//input[@name='addressDetail']"));
    public static final Target BTN_SIGUIENTE = Target.the("Boton siguiente").located(By.xpath("//button[@id='f-a-button__next-step-four']"));

}
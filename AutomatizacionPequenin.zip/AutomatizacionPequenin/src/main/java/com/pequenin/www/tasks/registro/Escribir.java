package com.pequenin.www.tasks.registro;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.pequenin.www.userinterfaces.registro.DatosContactoPage.*;

public class Escribir implements Task {
    String correoElectronico;
    String numeroCelular;

    public Escribir(String correoElectronico, String numeroCelular) {
        this.correoElectronico = correoElectronico;
        this.numeroCelular = numeroCelular;
    }



    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(

                Click.on(TXT_CORREO),
                Enter.theValue(correoElectronico).into(TXT_CORREO),
                Enter.theValue(numeroCelular).into(TXT_CELULAR),
                Click.on(RADIO_BUTTON_CORREO),
                Click.on(BTN_SIGUIENTE)

        );

    }

    public static Escribir losDatosDeContacto(String correo, String celular){
        return Tasks.instrumented(Escribir.class, correo,celular);

    }
}

package com.pequenin.www.userinterfaces.agregaralcarrito;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class CarritoDeComprasPage {
    public static final Target BTN_FINALIZAR_COMPRA = Target.the("Finalizar compra").located(By.xpath("//button[@id='f-m-shoppingCart__conditions-button-next-tab']"));
}

package com.pequenin.www.questions.iniciarsesion;

import com.pequenin.www.userinterfaces.iniciosesion.InicioSesionPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ValidarRespuesta implements Question<String> {
    public static ValidarRespuesta enElCampoCorreo(){
        return new ValidarRespuesta();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(InicioSesionPage.TXT_MSJ_ERROR_CORREO).viewedBy(actor).asString();
    }
}

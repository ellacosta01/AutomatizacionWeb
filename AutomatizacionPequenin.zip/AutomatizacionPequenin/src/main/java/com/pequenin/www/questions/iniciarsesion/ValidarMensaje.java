package com.pequenin.www.questions.iniciarsesion;

import com.pequenin.www.userinterfaces.iniciosesion.InicioSesionPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ValidarMensaje implements Question<String> {
    public static ValidarMensaje enElCampoClave(){
        return new ValidarMensaje();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(InicioSesionPage.TXT_MSJ_ERROR_CLAVE).viewedBy(actor).asString();
    }
}

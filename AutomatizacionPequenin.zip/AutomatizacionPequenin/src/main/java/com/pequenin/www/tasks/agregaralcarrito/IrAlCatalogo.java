package com.pequenin.www.tasks.agregaralcarrito;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.home.HomePage.BTN_CATALOGO_DE_PREMIOS;
import static com.pequenin.www.userinterfaces.home.HomePage.BTN_CLUB_PEQUENIN;

public class IrAlCatalogo implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Esperar.unTiempo(5000),
                Click.on(BTN_CLUB_PEQUENIN),
                Click.on(BTN_CATALOGO_DE_PREMIOS)
        );
    }
    public static IrAlCatalogo dePremios(){
        return Tasks.instrumented(IrAlCatalogo.class);
    }
}

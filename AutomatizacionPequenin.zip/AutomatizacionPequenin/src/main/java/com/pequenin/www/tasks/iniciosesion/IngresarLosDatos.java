package com.pequenin.www.tasks.iniciosesion;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.pequenin.www.userinterfaces.home.HomePage.BTN_INICIO_SESION;
import static com.pequenin.www.userinterfaces.iniciosesion.InicioSesionPage.TXT_CLAVE;
import static com.pequenin.www.userinterfaces.iniciosesion.InicioSesionPage.TXT_CORREO;

public class IngresarLosDatos implements Task {

    String correo;
    String clave;

    public IngresarLosDatos(String correo, String clave) {
        this.correo = correo;
        this.clave = clave;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_INICIO_SESION),
                Enter.theValue(correo).into(TXT_CORREO),
                Click.on(TXT_CLAVE),
                Enter.theValue(clave).into(TXT_CLAVE)

                );
    }

    public static IngresarLosDatos paraIniciarSesion(String correo, String clave) {
        return Tasks.instrumented(IngresarLosDatos.class, correo, clave);
    }
}

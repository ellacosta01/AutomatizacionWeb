package com.pequenin.www.userinterfaces.registro;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;


@DefaultUrl("https://d1dp8da9ty41k2.cloudfront.net/")
public class PequeninRegistoPage extends PageObject {


    public static final Target BTN_COMENZAR = Target.the("Boton comenzar").located(By.xpath("//button[@id='f-a-button__start']"));
    public static final Target TXT_NOMBRE = Target.the("Escribir nombre").located(By.xpath("//input[@name='nombre']"));
    public static final Target TXT_APELLIDO = Target.the("Escribir apellido").located(By.xpath("//input[@name='apellido']"));
    public static final Target TXT_CEDULA = Target.the("Escribir documento").located(By.xpath("//input[@name='documento']"));
    public static final Target TXT_FECHA = Target.the("Seleccionar Fecha").located(By.xpath("//input[@class='f-a-customCalendar__input']"));
    public static final Target BTN_MES = Target.the("Seleccionar mes").located(By.xpath("(//button[@class='Calendar__monthText'])[1]"));
    public static final Target BTN_YEAR = Target.the("Seleccionar year").located(By.xpath("(//button[@class='Calendar__yearText'])[1]"));

    public static Target BTN_YEAR_ESPECIFICO(String year) {
        return Target.the("Seleccionar year especifico " + year).located(By.xpath("//button[@class='Calendar__yearSelectorText' and text()='" + year + "']"));
    }

    public static Target BTN_MES_ESPECIFICO(String mes) {
        return Target.the("Seleccionar mes especifico " + mes).located(By.xpath("//button[@class='Calendar__monthSelectorItemText' and text()='" + mes + "']"));
    }

    public static Target BTN_DIA_ESPECIFICO(String dia) {
        return Target.the("Seleccionar dia especifico " + dia).located(By.xpath("(//div[@class='Calendar__day -ltr ' and text()='" + dia + "'])[1]"));
    }

    public static final Target BTN_TERMINOS_CONDICIONES = Target.the("Seleccionar terminos y condiciones").located(By.xpath("//input[@name='conditionsCheckBox']"));
    public static final Target BTN_SIGUIENTE = Target.the("Seleccionar boton siguiente").located(By.xpath("//button[@id='f-a-button__next-step-one']"));

}

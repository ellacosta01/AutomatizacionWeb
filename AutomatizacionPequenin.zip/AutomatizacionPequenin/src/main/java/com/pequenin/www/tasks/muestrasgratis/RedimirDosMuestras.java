package com.pequenin.www.tasks.muestrasgratis;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.muestrasgratis.MuestrasGratisPage.*;

public class RedimirDosMuestras implements Task {


    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Esperar.unTiempo(3000),
                Scroll.to(BTN_PREMIUM_TOUCH5).andAlignToBottom(),
                Esperar.unTiempo(2000),
                Click.on(BTN_PREMIUM_TOUCH3),
                Esperar.unTiempo(2000),
                Click.on(BTN_PREMIUM_TOUCH3));

    }
    public static RedimirDosMuestras iguales(){
        return Tasks.instrumented(RedimirDosMuestras.class);
    }
}

package com.pequenin.www.questions.datosdeenvio;

import com.pequenin.www.userinterfaces.datosdeenvio.ConfirmacionDireccionPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class Corroborar implements Question<String> {
  public static Corroborar ciudadYDepartmanto(){
      return new Corroborar();
  }



    @Override
    public String answeredBy(Actor actor) {
        return Text.of(ConfirmacionDireccionPage.TXT_CIUDAD_DE_ENVIO).viewedBy(actor).asString();
    }
}

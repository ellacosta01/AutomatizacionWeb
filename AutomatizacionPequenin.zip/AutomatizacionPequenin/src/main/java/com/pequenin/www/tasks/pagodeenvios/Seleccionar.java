package com.pequenin.www.tasks.pagodeenvios;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage.*;

public class Seleccionar implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_PAGO_EN_LINEA));
        actor.attemptsTo(
                Esperar.unTiempo(3000),
                Scroll.to(BTN_CONTINUAR).andAlignToBottom(),
                Esperar.unTiempo(3000),
                MoveMouse.to(BTN_CONTINUAR).andThen(actions -> actions.click())
        );
    }

    public static Seleccionar enMetodoDePago() {
        return Tasks.instrumented(Seleccionar.class);
    }
}

package com.pequenin.www.userinterfaces.registro;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class DatosContactoPage {

    public static final Target TXT_CORREO = Target.the("Escribir correo").located(By.xpath("//input[@name='email']"));
    public static final Target TXT_CELULAR = Target.the("Escribir celular").located(By.xpath("//input[@name='cellPhone']"));
    public static final Target RADIO_BUTTON_CORREO = Target.the("Escribir celular").located(By.xpath("(//div[@class='f-m-StepThreeRegister__activation-item-inner'])[1]"));
    public static final Target BTN_SIGUIENTE = Target.the("Boton siguiente").located(By.xpath("//button[@id='f-a-button__next-step-three']"));


    }

package com.pequenin.www.userinterfaces.muestrasgratis;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class DatosDeEnvioMuestrasGratisPage {
    public static final Target BTN_CONFIRMAR_ENVIO = Target.the("Boton Confirmar Envio").located(By.xpath("//button[@id='f-a-button__f-m-shipping-adress']"));






}

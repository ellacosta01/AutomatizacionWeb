package com.pequenin.www.tasks.muestrasgratis;

import com.pequenin.www.interactions.Esperar;
import com.pequenin.www.interactions.SeleccionarCiudad;
import com.pequenin.www.interactions.SeleccionarDepartamento;
import com.pequenin.www.interactions.SeleccionarTipoDeDireccion;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.datosdeenvio.DatosDeEnvioPage.*;
import static com.pequenin.www.userinterfaces.muestrasgratis.DatosDeEnvioMuestrasGratisPage.BTN_CONFIRMAR_ENVIO;

public class DiligenciarLosDatos implements Task {
    String tipoviaprincipal;
    String viaprincipal;
    String viasecundaria;
    String viacomplemento;
    String apto;
    String departamento;
    String ciudad;

    public DiligenciarLosDatos(String tipoviaprincipal, String viaprincipal, String viasecundaria, String viacomplemento,
                               String apto, String departamento, String ciudad) {
        this.tipoviaprincipal = tipoviaprincipal;
        this.viaprincipal = viaprincipal;
        this.viasecundaria = viasecundaria;
        this.viacomplemento = viacomplemento;
        this.apto = apto;
        this.departamento = departamento;
        this.ciudad = ciudad;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Esperar.unTiempo(2000),
                Scroll.to(BTN_CONFIRMAR_ENVIO).andAlignToBottom(),
                SeleccionarDepartamento.deEnvio(departamento),
                SeleccionarCiudad.deEnvio(ciudad),
                SeleccionarTipoDeDireccion.deEnvio(tipoviaprincipal),
                Enter.theValue(viaprincipal).into(TXT_VIA_PRINCIPAL),
                Enter.theValue(viasecundaria).into(TXT_VIA_SECUNDARIA),
                Enter.theValue(viacomplemento).into(TXT_VIA_COMPLEMENTO),
                Enter.theValue(apto).into(TXT_APTO),
                Click.on(BTN_CONFIRMAR_ENVIO),
                Esperar.unTiempo(3000)
        );

    }

    public static DiligenciarLosDatos deEnvio(String tipoviaprincipal, String viaprincipal, String viasecundaria, String viacomplemento,
                                              String apto, String departamento, String ciudad) {

        return Tasks.instrumented(DiligenciarLosDatos.class, tipoviaprincipal, viaprincipal, viasecundaria, viacomplemento, apto, departamento, ciudad);
    }
}
package com.pequenin.www.tasks.registro;

import com.pequenin.www.interactions.SeleccionarCiudad;
import com.pequenin.www.interactions.SeleccionarDepartamento;
import com.pequenin.www.userinterfaces.registro.DireccionPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.pequenin.www.userinterfaces.registro.DireccionPage.TXT_BARRIO;
import static com.pequenin.www.userinterfaces.registro.DireccionPage.TXT_DIRECCION;

public class Diligenciar implements Task {


    String direccion;
    String barrio;
    String departamento;
    String ciudad;

    public Diligenciar(String direccion, String barrio, String departamento, String ciudad) {
        this.direccion = direccion;
        this.barrio = barrio;
        this.departamento = departamento;
        this.ciudad = ciudad;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(SeleccionarDepartamento.deResidencia(departamento));
        actor.attemptsTo(SeleccionarCiudad.deResidencia(ciudad));
        actor.attemptsTo(
                Click.on(TXT_DIRECCION),
                Enter.theValue(direccion).into(TXT_DIRECCION),
                Click.on(TXT_BARRIO),
                Enter.theValue(barrio).into(TXT_BARRIO),
                Click.on(DireccionPage.BTN_SIGUIENTE)
                );

    }
    public static Diligenciar losDatosDeResidencia(String direccion, String barrio, String departamento, String ciudad){
        return Tasks.instrumented(Diligenciar.class,direccion,barrio, departamento, ciudad);

    }
}

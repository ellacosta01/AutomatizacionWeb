package com.pequenin.www.interactions;

import com.pequenin.www.userinterfaces.registro.DireccionPage;
import net.serenitybdd.core.time.InternalSystemClock;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Scroll;

public class SeleccionarCiudad implements Interaction {

    String ciudad;
    boolean envio = false;

    public SeleccionarCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    public SeleccionarCiudad(String ciudad, boolean envio) {
        this.ciudad = ciudad;
        this.envio = envio;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(DireccionPage.SELECT_CIUDAD));
        if(!envio) {
            actor.attemptsTo(Scroll.to(DireccionPage.OPT_CIUDAD_ESPECIFICA(ciudad)).andAlignToTop());
        }
        else {
            actor.attemptsTo(Scroll.to(DireccionPage.OPT_CIUDAD_ESPECIFICA(ciudad)).andAlignToBottom());
            new InternalSystemClock().pauseFor(2000);
        }
        actor.attemptsTo(Click.on(DireccionPage.OPT_CIUDAD_ESPECIFICA(ciudad)));
    }

    public static SeleccionarCiudad deResidencia(String ciudad) {
        return Tasks.instrumented(SeleccionarCiudad.class, ciudad);
    }

    public static SeleccionarCiudad deEnvio(String ciudad) {
        return Tasks.instrumented(SeleccionarCiudad.class, ciudad, true);
    }
}

package com.pequenin.www.questions.muestragratis;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static com.pequenin.www.userinterfaces.muestrasgratis.MensajesEstadoDeRedencionPage.TXT_MUESTRA_DOBLE;

public class ValidarMensajeError implements Question<String> {


    @Override
    public String answeredBy(Actor actor) {
        return Text.of(TXT_MUESTRA_DOBLE).viewedBy(actor).asString();
    }
    public static ValidarMensajeError deMuestraDoble(){
        return new ValidarMensajeError();
    }
}

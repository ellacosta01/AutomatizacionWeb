package com.pequenin.www.tasks.datosdeenvio;

import net.serenitybdd.core.time.InternalSystemClock;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;


import static com.pequenin.www.userinterfaces.agregaralcarrito.CarritoDeComprasPage.BTN_FINALIZAR_COMPRA;

public class SeleccionaElBoton implements Task {


    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(Scroll.to(BTN_FINALIZAR_COMPRA).andAlignToBottom());
        new InternalSystemClock().pauseFor(3000);

        actor.attemptsTo(MoveMouse.to(BTN_FINALIZAR_COMPRA).andThen(actions -> actions.click()));
    }

    public static SeleccionaElBoton finalizarCompra() {
        return Tasks.instrumented(SeleccionaElBoton.class);
    }
}

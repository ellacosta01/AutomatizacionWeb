package com.pequenin.www.tasks.muestrasgratis;

import com.pequenin.www.interactions.Esperar;
import com.pequenin.www.interactions.SeleccionarCiudad;
import com.pequenin.www.interactions.SeleccionarDepartamento;
import com.pequenin.www.interactions.SeleccionarTipoDeDireccion;
import net.serenitybdd.core.time.InternalSystemClock;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.datosdeenvio.DatosDeEnvioPage.*;
import static com.pequenin.www.userinterfaces.datosdeenvio.DatosDeEnvioPage.TXT_APTO;
import static com.pequenin.www.userinterfaces.muestrasgratis.MuestrasGratisPage.*;
import static com.pequenin.www.userinterfaces.muestrasgratis.ProductosPanalesPage.BTN_ETAPA_4;
import static com.pequenin.www.userinterfaces.muestrasgratis.ProductosPanalesPage.BTN_PIDE_UNA_MUESTRA;

public class RealizarElProceso implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Esperar.unTiempo(2000),
                Click.on(BTN_ETAPA_4),
                Click.on(BTN_PIDE_UNA_MUESTRA),
                Esperar.unTiempo(2000),
                Click.on(BTN_CERRAR_VENTANA_MUESTRAS_GRATIS),
                Esperar.unTiempo(1000)

        );

    }

    public static RealizarElProceso deSolicitarUnaMuestra() {
        return Tasks.instrumented(RealizarElProceso.class);
    }
}

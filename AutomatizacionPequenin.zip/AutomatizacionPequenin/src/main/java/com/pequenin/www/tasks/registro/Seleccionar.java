package com.pequenin.www.tasks.registro;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.SelectFromOptions;

import java.util.List;

import static com.pequenin.www.userinterfaces.registro.RolPage.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class Seleccionar implements Task {

    List<String> listaRol;

    public Seleccionar(List<String> listaRol) {
        this.listaRol = listaRol;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {

        switch (listaRol.get(0).toLowerCase()) {
            case "mama":
                actor.attemptsTo(Click.on(BTN_MAMA));
                break;
            case "papa":
                actor.attemptsTo(Click.on(BTN_PAPA));
                break;
            case "otro":
                actor.attemptsTo(Click.on(BTN_OTRO), SelectFromOptions.byVisibleText(listaRol.get(1)).from(BTN_LISTA_ABUELO));
                break;
            default:
                throw new IllegalArgumentException("El rol seleccionado es inválido. Rol ingresado: " + listaRol.get(0));
        }
        actor.attemptsTo(
                Click.on(BTN_SIGUIENTE)
        );
    }


    public static Seleccionar elRol(List<String> listaRol) {
        return instrumented(Seleccionar.class, listaRol);

    }
}

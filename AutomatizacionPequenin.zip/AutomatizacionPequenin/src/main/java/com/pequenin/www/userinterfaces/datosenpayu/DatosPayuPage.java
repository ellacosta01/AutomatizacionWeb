package com.pequenin.www.userinterfaces.datosenpayu;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class DatosPayuPage {

    public static final Target BTN_FRANQUICIA = Target.the("Seleccionar Targeta").located(By.xpath("//button[@id='pm-MASTERCARD']"));

    public static final Target TXT_NOMBRE_USUARIO = Target.the("Nombre usuario").located(By.xpath("//input[@name='fullName']"));

    public static final Target TXT_DOCUMENTO = Target.the("Documento").located(By.xpath("//input[@name='dniNumber']"));

    public static final Target TXT_NUM_TARJETA = Target.the("Numero de tarjeta").located(By.xpath("//input[@name='addCreditCardNumber']"));

    public static final Target TXT_CODIGO_SEGURIDAD = Target.the("Codigo de seguridad").located(By.xpath("//input[@id='securityCodeAux_']"));

    public static final Target SELECT_DIA_VENCIMIENTO = Target.the("Dia de vencimiento").located(By.xpath("//select[@name='expirationMonth']"));

    public static final Target SELECT_YEAR_VENCIMIENTO = Target.the("Year de vencimiento").located(By.xpath("//select[@id='expirationDateYear']"));

    public static final Target SELECT_CUOTAS = Target.the("Seleccionar cuotas").located(By.xpath("//select[@id='installments']"));

    public static final Target CHECK_TERMINOS_CONDICIONES = Target.the("Seleccionar terminos y condiciones").located(By.xpath("//input[@id='tandc']"));

    public static final Target TXT_CELULAR = Target.the("Escribir celular").located(By.xpath("//input[@name='contactPhone']"));

    public static final Target BTN_PAGAR = Target.the("Pagar").located(By.xpath("//button[@id='buyer_data_button_pay']"));




}

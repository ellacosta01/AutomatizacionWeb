package com.pequenin.www.tasks.muestrasgratis;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.home.HomePage.BTN_PREMIUN_TOUCH;

public class Selecciona implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Click.on(BTN_PREMIUN_TOUCH)

        );
    }

    public static Selecciona elProducto(){
        return Tasks.instrumented(Selecciona.class);
    }
}

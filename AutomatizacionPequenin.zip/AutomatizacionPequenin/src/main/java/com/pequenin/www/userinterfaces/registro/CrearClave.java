package com.pequenin.www.userinterfaces.registro;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class CrearClave {
    public static final Target TXT_CLAVE = Target.the("Escribir clave").located(By.xpath("//input[@name='password']"));
    public static final Target BTN_SIGUIENTE = Target.the("Boton siguiente").located(By.xpath("//button[@id='f-a-button__next-step-seven']"));

}

package com.pequenin.www.userinterfaces.muestrasgratis;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class ProductosPanalesPage {

    public static final Target BTN_ETAPA_4 = Target.the("Boton etapa cuatro").located(By.xpath("(//div[@class='f-m-product-banner__stage-button '])[1]"));
    public static final Target BTN_PIDE_UNA_MUESTRA = Target.the("Boton pide una muestra").located(By.xpath("//button[@id='f-a-button__product-banner-sample']"));

}

package com.pequenin.www.questions.datosdeenvio;

import com.pequenin.www.userinterfaces.datosdeenvio.ConfirmacionDireccionPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class Verificar implements Question<String> {

    public static Verificar elBarrioOApato(){
    return new Verificar();

}

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(ConfirmacionDireccionPage.TXT_APTO).viewedBy(actor).asString();
    }
}

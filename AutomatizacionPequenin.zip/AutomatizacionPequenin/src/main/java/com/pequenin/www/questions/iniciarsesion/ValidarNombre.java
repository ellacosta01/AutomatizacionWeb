package com.pequenin.www.questions.iniciarsesion;

import com.pequenin.www.userinterfaces.home.HomePage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;


public class ValidarNombre implements Question<String>  {

    public static ValidarNombre delUsuario() {
        return new ValidarNombre();
    }
        @Override
    public String answeredBy(Actor actor) {
        return Text.of(HomePage.TXT_NOMBRE_USUARIO).viewedBy(actor).asString();
    }
    }

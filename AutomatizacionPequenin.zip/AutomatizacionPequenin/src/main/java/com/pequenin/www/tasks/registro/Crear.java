package com.pequenin.www.tasks.registro;

import com.pequenin.www.userinterfaces.registro.CrearClave;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.pequenin.www.userinterfaces.registro.CrearClave.TXT_CLAVE;

public class Crear implements Task {
    String clave;

    public Crear(String clave) {
        this.clave = clave;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(TXT_CLAVE),
                Enter.theValue(clave).into(TXT_CLAVE),
                Click.on(CrearClave.BTN_SIGUIENTE)
        );
    }

    public static Crear laClave(String clave) {
        return Tasks.instrumented(Crear.class, clave);
    }
}

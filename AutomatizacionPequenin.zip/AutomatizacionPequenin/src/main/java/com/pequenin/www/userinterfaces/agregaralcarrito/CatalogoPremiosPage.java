package com.pequenin.www.userinterfaces.agregaralcarrito;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class CatalogoPremiosPage {

    public static final Target BTN_KIT_DE_HERRAMIENTAS = Target.the("Boton tarjeta premio cartuchera").located(By.xpath("(//div[@class='f-a-card-item-image-container'])[1]"));
    public static final Target BTN_AGREGAR_AL_CARRITO = Target.the("Boton tarjeta premio cartuchera").located(By.xpath("//button[@id='f-a-button__rewardBanner']"));
    public static final Target BTN_VER_AL_CARRITO = Target.the("Boton ver premio").located(By.xpath("//div[@class='f-a-addedRewardToast__button']/button"));
    public static final Target BTN_PRODUCTO_AGREGADO = Target.the("detalle del producto del carrito").located(By.xpath("//h3[@class='f-m-cartModal__item-name' and text()='Kit de herramientas']"));
    public static final Target BTN_CONTINUAR_CARRITO = Target.the("Continuar en el carrito").located(By.xpath("//button[@id='f-a-button__cartModal']"));


}

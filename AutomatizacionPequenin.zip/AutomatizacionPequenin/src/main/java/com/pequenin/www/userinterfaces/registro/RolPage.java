package com.pequenin.www.userinterfaces.registro;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class RolPage {
    public static final Target BTN_MAMA = Target.the("Boton rol mama").located(By.xpath("(//div[@class='f-m-StepTwoRegister__role '])[1]"));
    public static final Target BTN_PAPA = Target.the("Boton rol papa").located(By.xpath("(//div[@class='f-m-StepTwoRegister__role '])[2]"));
    public static final Target BTN_OTRO = Target.the("Boton rol otro").located(By.xpath("(//div[@class='f-m-StepTwoRegister__role '])[3]"));
    public static final Target BTN_LISTA = Target.the("Boton lista desplegable").located(By.xpath("//div[@class='f-a-selectBox__select-inner']"));
    public static final Target BTN_LISTA_ABUELO = Target.the("Boton rol abuelo").located(By.xpath("(//li[@class='f-a-selectBox__option'])[1]"));
    public static final Target BTN_LISTA_TIO_A = Target.the("Boton rol tio/a").located(By.xpath("(//li[@class='f-a-selectBox__option'])[2]"));
    public static final Target BTN_LISTA_HERMANO_A = Target.the("Boton rol hermano/a").located(By.xpath("(//li[@class='f-a-selectBox__option'])[3]"));
    public static final Target BTN_LISTA_MADRINA = Target.the("Boton rol madrina").located(By.xpath("(//li[@class='f-a-selectBox__option'])[4]"));
    public static final Target BTN_LISTA_PADRINO = Target.the("Boton rol padrino").located(By.xpath("(//li[@class='f-a-selectBox__option'])[5]"));
    public static final Target BTN_SIGUIENTE = Target.the("Boton siguiente").located(By.xpath("//button[@id='f-a-button__next-step-two']"));


}

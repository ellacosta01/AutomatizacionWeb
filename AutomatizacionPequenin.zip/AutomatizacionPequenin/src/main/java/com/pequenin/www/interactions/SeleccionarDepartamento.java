package com.pequenin.www.interactions;

import com.pequenin.www.userinterfaces.registro.DireccionPage;
import net.serenitybdd.core.time.InternalSystemClock;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Scroll;

public class SeleccionarDepartamento implements Interaction {

    String departamento;
    boolean envio = false;

    public SeleccionarDepartamento(String departamento) {
        this.departamento = departamento;
    }
    public SeleccionarDepartamento(String departamento, boolean envio) {
        this.departamento = departamento;
        this.envio = envio;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(DireccionPage.SELECT_DEPARTAMENTO));
        if(!envio) {
            actor.attemptsTo(Scroll.to(DireccionPage.OPT_DEPARTAMENTO_ESPECIFICO(departamento)).andAlignToTop());
        }
        else {
            actor.attemptsTo(Scroll.to(DireccionPage.OPT_DEPARTAMENTO_ESPECIFICO(departamento)).andAlignToBottom());
            new InternalSystemClock().pauseFor(2000);
        }
        actor.attemptsTo(Click.on(DireccionPage.OPT_DEPARTAMENTO_ESPECIFICO(departamento)));
    }

    public static SeleccionarDepartamento deResidencia(String departamento) {
        return Tasks.instrumented(SeleccionarDepartamento.class, departamento);
    }
    public static SeleccionarDepartamento deEnvio(String departamento) {
        return Tasks.instrumented(SeleccionarDepartamento.class, departamento, true);
    }
}

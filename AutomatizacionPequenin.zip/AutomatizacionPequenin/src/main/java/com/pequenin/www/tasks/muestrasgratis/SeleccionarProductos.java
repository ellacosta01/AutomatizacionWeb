package com.pequenin.www.tasks.muestrasgratis;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.home.HomePage.BTN_PRODUCTOS;

public class SeleccionarProductos implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Esperar.unTiempo(5000),
                Click.on(BTN_PRODUCTOS)
        );




    }

    public static SeleccionarProductos enElHome() {
        return Tasks.instrumented(SeleccionarProductos.class);
    }
}
package com.pequenin.www.tasks.pagoscontraentrega;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage.BTN_PAGO_CONTRA_ENTREGA;

public class Selecciona implements Task {



    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Esperar.unTiempo(3000),
                Click.on(BTN_PAGO_CONTRA_ENTREGA)

        );

    }

    public static Selecciona elMetodoDePago(){
        return Tasks.instrumented(Selecciona.class);
    }
}

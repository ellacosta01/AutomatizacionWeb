package com.pequenin.www.tasks.datosenpayu;

import com.pequenin.www.interactions.Esperar;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;

import static com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage.BTN_CONFIRMAR_PAGO;
import static com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage.BTN_CONTINUAR;

public class Confirmar implements Task {

    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Scroll.to(BTN_CONTINUAR).andAlignToBottom(),
                Esperar.unTiempo(4000),
                MoveMouse.to(BTN_CONTINUAR).andThen(actions -> actions.click()));
    }
    public static Confirmar elpago() {
        return Tasks.instrumented(Confirmar.class);
    }
}

package com.pequenin.www.tasks.registro;

import com.pequenin.www.userinterfaces.registro.SeleccionaEtapaPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.registro.SeleccionaEtapaPage.BTN_QUEDAR_EN_EMBARAZO;

public class Escoger implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(

                Click.on(BTN_QUEDAR_EN_EMBARAZO),
                Click.on(SeleccionaEtapaPage.BTN_SIGUIENTE)
        );
    }

    public static Escoger laEtapa ()
    {
        return Tasks.instrumented(Escoger.class);
    }
}

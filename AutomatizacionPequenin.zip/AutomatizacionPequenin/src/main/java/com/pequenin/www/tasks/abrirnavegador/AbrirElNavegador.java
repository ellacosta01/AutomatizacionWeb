package com.pequenin.www.tasks.abrirnavegador;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Open;

public class AbrirElNavegador implements Task {
    PageObject Page;

    public AbrirElNavegador(PageObject page) {
        this.Page = page;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Open.browserOn(Page));
    }

    public static AbrirElNavegador en(PageObject page) {
        return Tasks.instrumented(AbrirElNavegador.class, page);
    }
}

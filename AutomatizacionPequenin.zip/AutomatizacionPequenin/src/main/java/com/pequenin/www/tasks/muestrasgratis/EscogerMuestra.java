package com.pequenin.www.tasks.muestrasgratis;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.pequenin.www.userinterfaces.muestrasgratis.MuestrasGratisPage.BTN_NEW_BABY;
import static com.pequenin.www.userinterfaces.muestrasgratis.MuestrasGratisPage.BTN_SOLICITA_MUESTRA;

public class EscogerMuestra implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {


        actor.attemptsTo(
                Click.on(BTN_NEW_BABY),
                Click.on(BTN_SOLICITA_MUESTRA));
    }
    public static EscogerMuestra disponible(){
        return Tasks.instrumented(EscogerMuestra.class);
    }
}

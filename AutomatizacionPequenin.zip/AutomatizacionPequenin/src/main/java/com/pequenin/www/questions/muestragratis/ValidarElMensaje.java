package com.pequenin.www.questions.muestragratis;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static com.pequenin.www.userinterfaces.muestrasgratis.MensajesEstadoDeRedencionPage.TXT_SOLICITA_MUESTRA;

public class ValidarElMensaje implements Question<String>  {

   public static ValidarElMensaje deMuestraExitosa(){
       return new ValidarElMensaje();
   }


    @Override
    public String answeredBy(Actor actor) {
        return Text.of(TXT_SOLICITA_MUESTRA).viewedBy(actor).asString();
    }
}

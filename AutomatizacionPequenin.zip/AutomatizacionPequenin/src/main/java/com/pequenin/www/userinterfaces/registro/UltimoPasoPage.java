package com.pequenin.www.userinterfaces.registro;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class UltimoPasoPage {
    public static final Target BTN_FINALIZAR= Target.the("Boton Finalizat").located((By.xpath("//button[@id='f-a-button__EndRegister']")));
    public static final Target TXT_MENSAJE= Target.the("Boton Finalizat").located((By.xpath("//p[@class='f-m-EndRegister__title']")));


}

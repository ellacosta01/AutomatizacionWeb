package com.pequenin.www.userinterfaces.datosdeenvio;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.screenplay.targets.Target;

public class DatosDeEnvioPage {
    public static final Target TXT_NOMBRE = Target.the("Escribir nombre").located(By.xpath("//input[@name='name']"));
    public static final Target TXT_APELLIDO = Target.the("Escribir Apellido").located(By.xpath("//input[@name='lastName']"));
    public static final Target TXT_VIA_PRINCIPAL = Target.the("Escribir Via Principal").located(By.xpath("//input[@name='addressPart2']"));
    public static final Target TXT_VIA_SECUNDARIA = Target.the("Escribir Via Secundaria").located(By.xpath("//input[@name='addressPart3']"));
    public static final Target TXT_VIA_COMPLEMENTO = Target.the("Escribir Via Complemento").located(By.xpath("//input[@name='addressPart4']"));
    public static final Target TXT_APTO = Target.the("Escribir Apto").located(By.xpath("//input[@name='addressDetail']"));
    public static final Target TXT_NUMERO_CELULAR = Target.the("Escribir numero de celular").located(By.xpath("//input[@name='cellPhone']"));
    public static final Target BTN_CONTINUAR = Target.the("Boton continuar").located(By.xpath("//button[@id='f-a-buttton__shipping-info']"));
    public static final Target BTN_NO_ACTALIZAR_DATOS = Target.the("Boton No Actualizar los datos").located(By.xpath("//input[@id='radioNo']"));

}

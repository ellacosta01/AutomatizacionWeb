package com.pequenin.www.questions.pagosdeenvio;

import com.pequenin.www.userinterfaces.pagosdeenvio.PagosDeEnvioPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class Validar implements Question<String> {


    @Override
    public String answeredBy(Actor actor) {
        return Text.of(PagosDeEnvioPage.TXT_MENSAJE).viewedBy(actor).asString();


    }
    public static Validar elMensaje(){
        return new Validar();
    }
}

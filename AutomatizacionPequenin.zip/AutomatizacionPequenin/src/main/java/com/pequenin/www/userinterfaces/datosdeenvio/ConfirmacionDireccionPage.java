package com.pequenin.www.userinterfaces.datosdeenvio;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class ConfirmacionDireccionPage {
    public static final Target TXT_DIRECCION =Target.the("Direccion de envio").located(By.xpath("(//div[@class='f-m-adress-confirmation__info']/p)[1]"));
    public static final Target TXT_APTO =Target.the("Apto de envio").located(By.xpath("(//div[@class='f-m-adress-confirmation__info']/p)[2]"));
    public static final Target TXT_CIUDAD_DE_ENVIO =Target.the("Direccion de envio").located(By.xpath("(//div[@class='f-m-adress-confirmation__info']/p)[3]"));

}

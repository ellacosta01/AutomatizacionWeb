package com.vivaair.questions;

import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.List;

import static com.vivaair.userinterfaces.HomeVivaAirPage.LABEL_CIUDAD_DESTINO;

public class CiudadDestino implements Question {

    String destino;

    public CiudadDestino(String destino) {
        this.destino = destino;
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        List<WebElementFacade> listaCiudadDestino = LABEL_CIUDAD_DESTINO.resolveAllFor(actor);
        for (int i = 0; i < listaCiudadDestino.size(); i++) {

            if (!listaCiudadDestino.get(i).getText().equals(destino)) return false;
        }
            return true;
    }
    public static CiudadDestino aViajar (String destino){
        return new CiudadDestino(destino);
    }

}

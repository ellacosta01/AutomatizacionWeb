package com.vivaair.questions;

import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.List;

import static com.vivaair.userinterfaces.HomeVivaAirPage.LABEL_CIUDAD_ORIGEN;


public class CiudadOrigen implements Question<Boolean> {
    String origen;

    public CiudadOrigen(String origen) {
        this.origen = origen;
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<WebElementFacade> listaCiudadOrigen = LABEL_CIUDAD_ORIGEN.resolveAllFor(actor);
        for (int i = 0; i < listaCiudadOrigen.size(); i++) {
           // System.out.println(listaCiudadOrigen.get(i).getText());
            //System.out.println(origen);
            if(!listaCiudadOrigen.get(i).getText().equals(origen)) return false;
        }
        return true;
    }
        public static CiudadOrigen aViajar (String origen){
            return new CiudadOrigen(origen);
        }
    }

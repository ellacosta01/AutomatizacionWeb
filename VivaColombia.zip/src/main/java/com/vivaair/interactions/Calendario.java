package com.vivaair.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.vivaair.userinterfaces.HomeVivaAirPage.*;

public class Calendario implements Interaction {

    String dia;
    String mes;

    public Calendario(String dia, String mes) {
        this.dia = dia;
        this.mes = mes;
    }


    @Override
    public <T extends Actor> void performAs(T actor) {
        boolean bandera = true;
        while (!LBL_MES.of(mes).resolveFor(actor).isVisible()) {

            if (bandera) {
                bandera = false;
                actor.attemptsTo(Click.on(FLECHA_DERECHA));
            } else {
                actor.attemptsTo(Click.on(FLECHA_AVANZAR));
            }
        }
        actor.attemptsTo(Click.on(BTN_DIA.of(mes,dia).resolveFor(actor)));
    }

    public static Calendario seleccionarFecha(String dia, String mes) {
        return Tasks.instrumented(Calendario.class, dia, mes);
    }
}
package com.vivaair.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import static com.vivaair.userinterfaces.HomeVivaAirPage.BTN_CANTIDAD_PASAJEROS;
import static com.vivaair.userinterfaces.HomeVivaAirPage.LBL_NUMERO_PASAJEROS;


public class Numero implements Interaction {

    String adultos;
    String jovenes;
    String infantes;

    public Numero(String adultos, String jovenes, String infantes) {
        this.adultos = adultos;
        this.jovenes = jovenes;
        this.infantes = infantes;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        while (Integer.parseInt(adultos) > Integer.parseInt(LBL_NUMERO_PASAJEROS.of("Adulto(s)").resolveFor(actor).getText())) {
            actor.attemptsTo(Click.on(BTN_CANTIDAD_PASAJEROS.of("Adulto(s)", "2")));
        }
        while (Integer.parseInt(jovenes) > Integer.parseInt(LBL_NUMERO_PASAJEROS.of("Niño(s)").resolveFor(actor).getText())) {
            actor.attemptsTo(Click.on(BTN_CANTIDAD_PASAJEROS.of("Niño(s)", "2")));

        }
        while (Integer.parseInt(infantes) > Integer.parseInt(LBL_NUMERO_PASAJEROS.of("Infante(s)").resolveFor(actor).getText())) {
            actor.attemptsTo(Click.on(BTN_CANTIDAD_PASAJEROS.of("Infante(s)", "2")));

        }
    }

    public static Numero dePasajeros(String adultos, String jovenes, String infantes) {
        return Tasks.instrumented(Numero.class, adultos, jovenes, infantes);
    }
}


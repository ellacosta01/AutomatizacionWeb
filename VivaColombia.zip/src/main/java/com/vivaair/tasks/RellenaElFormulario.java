package com.vivaair.tasks;

import com.vivaair.interactions.Calendario;
import com.vivaair.interactions.Numero;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Hit;
import net.serenitybdd.screenplay.waits.Wait;
import org.hamcrest.Matchers;
import org.openqa.selenium.Keys;

import static com.vivaair.userinterfaces.HomeVivaAirPage.*;

public class RellenaElFormulario implements Task {

    String ciudadOrigen;
    String ciudadDestino;
    String checkInDia;
    String checkInMes;
    String checkOutDia;
    String checkOutMes;
    String adultos;
    String jovenes;
    String infantes;

    public RellenaElFormulario(String ciudadOrigen, String ciudadDestino, String checkInDia, String checkInMes, String checkOutDia, String checkOutMes, String adultos, String jovenes, String infantes) {
        this.ciudadOrigen = ciudadOrigen;
        this.ciudadDestino = ciudadDestino;
        this.checkInDia = checkInDia;
        this.checkInMes = checkInMes;
        this.checkOutDia = checkOutDia;
        this.checkOutMes = checkOutMes;
        this.adultos = adultos;
        this.jovenes = jovenes;
        this.infantes = infantes;


    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(BTN_CIUDAD_ORIGEN),
                Wait.until(
                        actor1 ->
                                // Lambda es una funcion anomima que no necesita ni mobre ni  de una clase
                                //la entrada de esa funcion lambda es un actor
                                //el metodo abstracto el que esta en la interfaz question esta la funcion abstracta
                                // la lambda e suna funcion anomima que reemplaza la abstracta
                                //resolverfor comvierte un target en un webelemetfacade - para que
                                // me diga si es visible o no para eso se transfotma en un elemento web
                                LIST_CIUDAD.of(ciudadOrigen).resolveFor(actor1).isVisible(),
                               //segunda entrada para que me diga el estado
                        Matchers.equalTo(true)).forNoLongerThan(20).seconds(),
                Click.on(BTN_CIUDAD_DESTINO),
                Click.on(BTN_CIUDAD_ORIGEN),
                Wait.until(
                        actor1 ->
                                LIST_CIUDAD.of(ciudadOrigen).resolveFor(actor1).isVisible(),
                        Matchers.equalTo(true)).forNoLongerThan(20).seconds(),
                Enter.theValue(ciudadOrigen).into(INPUT_CIUDAD_ORIGEN),
                Hit.the(Keys.ENTER).into(INPUT_CIUDAD_ORIGEN));

        actor.attemptsTo(Click.on(BTN_CIUDAD_DESTINO),
                //Para presionar una tecla en especifico -- thenHit
                Enter.theValue(ciudadDestino).into(INPUT_CIUDAD_DESTINO).thenHit(Keys.ENTER),
                Calendario.seleccionarFecha(checkInDia, checkInMes),
                Calendario.seleccionarFecha(checkOutDia, checkOutMes),
                Click.on(BTN_PASAJEROS),
                Numero.dePasajeros(adultos, jovenes, infantes),
                Click.on(BTN_BUSCAR)


                //Click.on(BTN_CANTIDAD_PASAJEROS.of("Adulto(s)", "2"))
        );


    }

    public static RellenaElFormulario paraLaReserva(String ciudadOrigen, String ciudadDestino, String checkInDia, String checkInMesYear, String checkOutDia, String checkOutMesYear, String adultos, String jovenes, String infantes) {
        return Tasks.instrumented(RellenaElFormulario.class, ciudadOrigen, ciudadDestino, checkInDia, checkInMesYear, checkOutDia, checkOutMesYear, adultos, jovenes, infantes);
    }
}
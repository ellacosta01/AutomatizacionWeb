package com.vivaair.models;

public class ValorAPagar {
    String total;
    public ValorAPagar(String total) {
        this.total = total;
    }

    public String getTotal() {
        return total;
    }


}

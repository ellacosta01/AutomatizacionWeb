package com.vivaair.models;

public class FormularioReservaVuelo {
    //Atributos
    String ciudadOrigen;
    String ciudadDestino;
    String checkInDia;
    String checkInMes;
    String checkOutDia;
    String checkOutMes;
    String adultos;
    String jovenes;
    String infantes;

    //obtener valores de lso atributos
    public String getCiudadOrigen() { return ciudadOrigen; }

    public String getCiudadDestino() {
        return ciudadDestino;
    }

    public String getCheckInDia() {
        return checkInDia;
    }

    public String getCheckInMes() {
        return checkInMes;
    }

    public String getCheckOutDia() {
        return checkOutDia;
    }

    public String getCheckOutMes() {
        return checkOutMes;
    }

    public String getAdultos() { return adultos; }

    public String getJovenes() { return jovenes; }

    public String getInfantes() { return infantes; }

   //Inicializar atributos
    public FormularioReservaVuelo(String ciudadOrigen, String ciudadDestino, String checkInDia, String checkInMes, String checkOutDia, String checkOutMes, String adultos, String jovenes, String infantes) {
        this.ciudadOrigen = ciudadOrigen;
        this.ciudadDestino = ciudadDestino;
        this.checkInDia = checkInDia;
        this.checkInMes = checkInMes;
        this.checkOutDia = checkOutDia;
        this.checkOutMes = checkOutMes;
        this.adultos = adultos;
        this.jovenes = jovenes;
        this.infantes = infantes;
    }

}
package com.vivaair.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class HomeVivaAirPage {

    public static final Target BTN_CIUDAD_ORIGEN = Target.the("Dar click en ciudad de origen").locatedBy("//label[contains(text(),\"Origen\")]");
    public static final Target INPUT_CIUDAD_ORIGEN = Target.the("Digitar ciudad de origen").locatedBy("(//input[@id='filter-station'])[1]");
    public static final Target BTN_CIUDAD_DESTINO = Target.the("Dar click en ciudad de origen").locatedBy("//label[contains(text(),\"Destino\")]");
    public static final Target INPUT_CIUDAD_DESTINO = Target.the("Digitar ciudad de origen").locatedBy("(//input[@id='filter-station-second'])[1]");
    public static final Target LIST_CIUDAD = Target.the("Listado de ciudades").locatedBy("//span[contains(text(),'{0}')]");
    public static final Target LBL_MES = Target.the("Mes de viaje").locatedBy("//div[@class='calendar__date_picker']/descendant-or-self::span[contains(text(),'{0}')]");
    public static final Target BTN_DIA = Target.the("Dia de viaje").locatedBy("//div[@class='calendar__date_picker']/div[@class='month' and descendant-or-self::span[contains(text(),'{0}')]]/descendant::div[contains(text(), '{1}')]");
    public static final Target FLECHA_DERECHA = Target.the("Flecha avanzar").locatedBy("//div[@class='calendar__date_picker__nav']");
    public static final Target FLECHA_AVANZAR = Target.the("Flecha avanzar").locatedBy("(//div[@class='calendar__date_picker__nav'])[2]");
    public static final Target BTN_PASAJEROS = Target.the("Texto Numero de pasajeros").locatedBy("//label[contains(text(),'1 Adulto, 0 Niños, 0 Infantes')]");
    public static final Target BTN_CANTIDAD_PASAJEROS = Target.the("Boton numero de pasajeros").locatedBy("(//div[@class='passenger__wrapper' and descendant-or-self::span[contains(text(),'{0}')]]//descendant::div[contains(@class, 'passenger__wrapper__row-action')])[{1}]");
    public static final Target LBL_NUMERO_PASAJEROS = Target.the("Mostrar numero de pasajeros").locatedBy("//div[@class='passenger__wrapper' and descendant-or-self::span[contains(text(),'{0}')]]/span");
    public static final Target BTN_BUSCAR = Target.the("Boton buscar").locatedBy("//button[@class='btn-blue ibe__button__desktop ibe__button']");
    public static final Target LABEL_CIUDAD_ORIGEN = Target.the("Label Ciudad Origen").locatedBy("//h2[@class='airport departure__airport']");
    public static final Target LABEL_CIUDAD_DESTINO = Target.the("Label Ciudad Destino").locatedBy("//h2[@class='airport arrival__airport']");





}

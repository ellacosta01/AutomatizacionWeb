package com.vivaair.hook;

import cucumber.api.java.Before;
import cucumber.api.java.es.Dado;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

public class Hook {
    @Managed
    private WebDriver hisBrowser;

    @Before
    public void setUp() {
        OnStage.setTheStage(new OnlineCast());
        OnStage.theActorCalled("El usuario").can(BrowseTheWeb.with(hisBrowser));
    }

    @Dado("^que me encuentro en el home de la pagina Viva Air$")
    public void queElUsuarioSeEncuentraEnLaPaginaDeReservasDeVuelos() {
        OnStage.theActorInTheSpotlight().attemptsTo(Open.url("https://www.vivaair.com/#/co/es"));

    }
}
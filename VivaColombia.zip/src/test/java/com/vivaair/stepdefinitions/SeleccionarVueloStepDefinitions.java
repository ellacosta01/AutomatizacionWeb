package com.vivaair.stepdefinitions;

import com.vivaair.models.FormularioReservaVuelo;
import com.vivaair.questions.CiudadDestino;
import com.vivaair.questions.CiudadOrigen;
import com.vivaair.tasks.RellenaElFormulario;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Entonces;

import java.util.List;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;

public class SeleccionarVueloStepDefinitions {


    @Cuando("^ingreso los datos basicos para buscar un vuelo ida y regreso$")
    public void ingreso_los_datos_basicos_para_buscar_un_vuelo_ida_y_regreso(List<FormularioReservaVuelo> listaFormularioReservaVuelo) {
        theActorInTheSpotlight().attemptsTo(RellenaElFormulario.paraLaReserva(
                //Llamar el primer objeto de la lista get.0 que es la fila del feature - la data, que toma dato por dato para cada ejecucion
                listaFormularioReservaVuelo.get(0).getCiudadOrigen(),
                listaFormularioReservaVuelo.get(0).getCiudadDestino(), listaFormularioReservaVuelo.get(0).getCheckInDia(),
                listaFormularioReservaVuelo.get(0).getCheckInMes(), listaFormularioReservaVuelo.get(0).getCheckOutDia(),
                listaFormularioReservaVuelo.get(0).getCheckOutMes(), listaFormularioReservaVuelo.get(0).getAdultos(),
                listaFormularioReservaVuelo.get(0).getJovenes(), listaFormularioReservaVuelo.get(0).getInfantes()));
    }

    @Entonces("^se valida que \"([^\"]*)\" es la ciudad de origen y \"([^\"]*)\" la ciudad de destino$")
    public void se_valida_que_es_la_ciudad_de_origen_y_la_ciudad_de_destino(String origen, String destino) {
        theActorInTheSpotlight().should(seeThat(CiudadOrigen.aViajar(origen), equalTo(true)));
        theActorInTheSpotlight().should(seeThat(CiudadDestino.aViajar(destino),equalTo(true)));
    }

}
